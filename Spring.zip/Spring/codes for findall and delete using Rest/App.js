import React, { PureComponent } from 'react'
import ListProductComponent from './component/ListProductComponent'
import './App.css'
class App extends PureComponent {
  constructor(props) {
    super(props)

    this.state = {
      
    }
  }

  render() {
    return (
      <div>
        <h1><center>My Product App</center></h1>
        <ListProductComponent></ListProductComponent>
      </div>
    )
  }
}

export default App