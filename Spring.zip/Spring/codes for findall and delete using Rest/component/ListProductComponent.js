import React, { PureComponent } from "react";
import ProductDataService from "../service/ProductDataService";

class ListProductComponent extends PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      product: [],
      message: ""
    };
    this.refreshProduct = this.refreshProduct.bind(this);
    this.deleteProductClick = this.deleteProductClick.bind(this);
  }

  componentWillMount() {
    this.refreshProduct();
  }
  refreshProduct() {
    ProductDataService.getAllProducts().then(response => {
      this.setState({
        product: response.data
      });
    });
  }
  deleteProductClick(productIdToDelete) {
    ProductDataService.deleteProduct(productIdToDelete).then(response => {
      this.setState({
        message: "Product Id " + productIdToDelete + " deleted successfully"
      });
      this.refreshProduct();
    });
  }
  render() {
    return (
      <div>
        <h2>All Products for you</h2>
        <div className="container">
          {this.state.message && 
            <div className="alert alert-success">{this.state.message}</div>}
          
          <table className="table table-striped table-hover">
            <thead>
              <tr>
                <th>ProductId</th>
                <th>ProductName</th>
                <th>Quantity On Hand</th>
                <th>Price</th>
                <th>Delete</th>
              </tr>
            </thead>

            <tbody>
              {this.state.product.map(product => (
                <tr key={product.productId}>
                  <td>{product.productId}</td>
                  <td>{product.productName}</td>
                  <td>{product.quantityOnHand}</td>
                  <td>{product.price}</td>
                  <td>
                    <button
                      className="btn btn-warning"
                      onClick={() => this.deleteProductClick(product.productId)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

export default ListProductComponent;
