package com.dxc.pms.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.dxc.pms.model.Product;
import com.dxc.pms.model.Review;
import com.mongodb.WriteResult;

@Repository
public class ReviewDAOImpl implements ReviewDAO{

	@Autowired
	ProductDAO productDAO;
	@Autowired
	MongoTemplate mongoTemplate;
	
	Product product = new Product();
	Review review = new Review();
	
	
	
	@Override
	public List<Review> getAllReview(int productId) {
		
		//Query query = new Query(Criteria.where("productId").is(productId));
		
		//List<Review> allReview = mongoTemplate.find(query, Review.class, "product");
		product = productDAO.getProduct(productId);
		List<Review> allReview = product.getReviews();
		System.out.println(allReview);
		
		//return mongoTemplate.findAll(Review.class);
		return allReview;
	}

	@Override
	public boolean addReview(int productId,Review review) {

		product = productDAO.getProduct(productId);
		
		//product.setReviews(review);
		
		List<Review> allReview = product.getReviews();
		allReview.add(review);
		product.setReviews(allReview);
		System.out.println("Inside DAO :" + review);
        System.out.println("Inside DAO :" + product);
		mongoTemplate.save(product, "product");
		return true;
	}

	@Override
	public Review getReview(int productId, int reviewId) {
		
		product = productDAO.getProduct(productId);
		
		for( Review REVIEW: product.getReviews()) {
			if(REVIEW.getReviewId()== reviewId) {
				review = REVIEW;
			}
		}
		System.out.println(review);
		return review;
	}
	@Override
    public boolean deleteReview(int productId, int reviewId) {
		
		
		product = productDAO.getProduct(productId);
		List<Review> allReview = product.getReviews();
		
		System.out.println(allReview);

		for (int i = 0; i < allReview.size(); i++) {
			if (allReview.get(i).getReviewId() == reviewId) {
				allReview.remove(i);
			}
		}

		product.setReviews(allReview);
		mongoTemplate.save(product, "product");
		return true;
			
		
	}

	@Override
	public boolean updateReview(int productId, int reviewId,Review review1) {
		product = productDAO.getProduct(productId);

		List<Review> allReviews = product.getReviews();

		for (Review review2 : allReviews) {
			if (review2.getReviewId() == reviewId) {

				System.out.println(review2);

				allReviews.remove(review2);

				allReviews.add(review1);

				product.setReviews(allReviews);

				mongoTemplate.save(product, "product");
			}
		}

		return true;

	}

	

	
}
