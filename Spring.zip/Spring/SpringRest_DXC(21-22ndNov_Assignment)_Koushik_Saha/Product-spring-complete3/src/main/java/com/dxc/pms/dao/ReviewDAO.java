package com.dxc.pms.dao;

import java.util.List;

import com.dxc.pms.model.Product;
import com.dxc.pms.model.Review;

public interface ReviewDAO {

	
	public List<Review> getAllReview(int productId);
	public boolean addReview(int productId,Review review);
	public Review getReview(int productId, int reviewId);
	public boolean deleteReview(int productId, int reviewId);
	public boolean updateReview(int productId, int reviewId,Review review);
	
}
