import React, { Component } from "react";
import ReviewService from "../service/ReviewService";
import { Formik, Form, Field, ErrorMessage } from "formik";

class ReviewComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      productId: this.props.match.params.productId,
      reviewId: this.props.match.params.reviewId,
      review: "",
      reviewRating: "",
      button: "Update",
      status1: true
    };
    this.onSubmit = this.onSubmit.bind(this);
    this.validateReviewForm = this.validateReviewForm.bind(this);
  }

  componentWillMount() {
    if (this.state.reviewId == -1) {
      this.setState({
        button: "Add",
        reviewId: "",
        status1: false
      });
    }

    //this following block of code is for...if update button is clicked..then already present review should be loaded...that's why..
    ReviewService.getReview(this.state.productId).then(response => {
      this.setState({
        //   productName: response.data.productName,
        review: response.data.review,
        reviewRating: response.data.reviewRating
      });
      //console.log(status1)
    });
  }

  onSubmit(review) {
    if (this.state.reviewId == "") {
      console.log("Hi");
      ReviewService.add_Review(this.state.productId, review).then(response => 
        {this.props.history.push("/");

        console.log(response.status);
      });
    } 
    else {
      ReviewService.updateReview(this.state.productId,this.state.reviewId,review).then(() =>
        this.props.history.push("/")
      );
    }
  }

  validateReviewForm(values) {
    let errors = {};
    if (!values.productId) {
      errors.productId = "Enter Product Id";
    } else if (!values.productName) {
      errors.productName = "Enter Product Name";
    } else if (!values.quantityOnHand) {
      errors.quantityOnHand = "Enter Quantity On Hand";
    } else if (values.quantityOnHand < 0) {
      errors.price = "Enter valid quantity on hand";
    } else if (values.price < 0) {
      errors.price = "Enter valid price";
    } else if (values.productName.length < 3) {
      errors.productName = "Enter at least 3 character";
    }
    return errors;
  }
  render() {
    let { reviewId, review, reviewRating } = this.state;
    return (
      <div>
        {/* <h3> Add/Update review</h3>  */}

        <div className="container">
          <Formik
            initialValues={{ reviewId, review, reviewRating }}
            enableReinitialize={true}
            onSubmit={this.onSubmit}
            validateOnBlur={false}
            validateOnChange={false}
            validate={this.validateProductForm}
          >
            <Form>
              <ErrorMessage
                name="reviewId"
                component="div"
                className="alert alert-warning"
              ></ErrorMessage>
              <ErrorMessage
                name="review"
                component="div"
                className="alert alert-warning"
              ></ErrorMessage>
              <ErrorMessage
                name="reviewRating"
                component="div"
                className="alert alert-warning"
              ></ErrorMessage>

              <fieldset className="form-group">
                <label>Review Id</label>
                <Field
                  className="form-control"
                  type="text"
                  name="reviewId"
                  disabled={this.state.status1}
                ></Field>
              </fieldset>
              <fieldset className="form-group">
                <label>Review</label>
                <Field
                  className="form-control"
                  type="text"
                  name="review"
                ></Field>
              </fieldset>
              <fieldset className="form-group">
                <label>Rating</label>
                <Field
                  className="form-control"
                  type="text"
                  name="reviewRating"
                ></Field>
              </fieldset>

              <button className="btn btn-success" type="submit">
                {this.state.button}
              </button>
            </Form>
          </Formik>
        </div>
      </div>
    );
  }
}

export default ReviewComponent;
