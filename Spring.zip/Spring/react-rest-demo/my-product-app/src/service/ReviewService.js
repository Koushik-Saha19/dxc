
import axios from "axios";

const REVIEW_API_URL = "http://localhost:8001/review";




class ReviewService  {


  
    getAllReviews(productId) {
        return axios.get(`${REVIEW_API_URL}/${productId}`);
      }
      deleteReview(productId,reviewId) {
        return axios.delete(`${REVIEW_API_URL}/delete/prodId:${productId}/rId:${reviewId}`);
      }
      getReview(productId,reviewId) {
        return axios.get(`${REVIEW_API_URL}/prodId:${productId}/rId:${reviewId}`);
      }
    
      updateReview(productId,reviewId,review) {
        return axios.put(`${REVIEW_API_URL}/update/prodId:${productId}/rId:${reviewId}`, review);
      }
    
      add_Review(productId,review) {
        return axios.post(`${REVIEW_API_URL}/${productId}`, review);
      }
    
}

export default new ReviewService();