import axios from "axios";

const PRODUCT_API_URL = "http://localhost:8001/product";


class ProductDataService {
  getAllProducts() {
    return axios.get(`${PRODUCT_API_URL}`);

  }
  deleteProduct(productId) {
    return axios.delete(`${PRODUCT_API_URL}/${productId}`);
  }
  getProduct(productId) {
    return axios.get(`${PRODUCT_API_URL}/${productId}`);
  }

  updateProduct(product) {
    return axios.put(`${PRODUCT_API_URL}/`, product);
  }

  addProduct(product) {
    return axios.post(`${PRODUCT_API_URL}/`, product);
  }
  searchProduct(productName) {
    return axios.get(`${PRODUCT_API_URL}/search/${productName}`);
  }
}

export default new ProductDataService();
