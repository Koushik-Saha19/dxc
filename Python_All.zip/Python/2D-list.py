n = input()
x = n.split()
# NUM_ROWS = int(input())
# NUM_COL = int(input())
NUM_ROWS = int(x[0])
NUM_COL = int(x[1])
a = [[int(input()) for j in range(NUM_COL)] for i in range(NUM_ROWS)]
multiplier = int(input())
for i in range(NUM_ROWS):
  for j in range(len(a[i])):
    print(multiplier*a[i][j], end=" ")
  print()