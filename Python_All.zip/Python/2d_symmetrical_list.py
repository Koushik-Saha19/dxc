n = int(input())
a = [[0 for x in range(n)] for y in range(n)] 
for i in range(n):
  for j in range(n):
    if(i==j):
      a[i][j] = 0
    if(j>i):
      a[i][j]=j-i
    if(j<i):
      a[i][j]=i-j
      
      
for i in range(n):
  for j in range(n):
      print(a[i][j],end=" ")
  print()