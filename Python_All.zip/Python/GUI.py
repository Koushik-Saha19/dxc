import tkinter as tk 

#Initialize
root = tk.Tk()
w = tk.Label(root, text="Hello Tkinter")
w.pack()

root.mainloop()


