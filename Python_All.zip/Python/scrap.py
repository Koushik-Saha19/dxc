import requests
from bs4 import BeautifulSoup

page = requests.get('https://github.com/trending')

soup = BeautifulSoup(page.text,'html.parser')

repo = soup.find(class_="explore-pjax-container container-lg p-responsive pt-6")

repo_list = repo.find_all(class_='Box-row')

print(len(repo_list))

for i in range(0,25):
    print(repo_list[i])
