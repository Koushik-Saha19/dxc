import tkinter as tk 

#Initialize
root = tk.Tk()

logo = tk.PhotoImage(file="giphy.gif")
w1 = tk.Label(root, text="Hello Tkinter",image=logo).pack(side="right")

explanation = "Hi Welcome"

w2 = tk.Label(root, justify=tk.LEFT,padx=10,text=explanation).pack(side="left")

root.mainloop()


