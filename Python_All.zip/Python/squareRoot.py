# from math import sqrt
import math
num = float(input("Enter the number"))

root = math.sqrt(num)
print("Square root of ", num , "=", root)

