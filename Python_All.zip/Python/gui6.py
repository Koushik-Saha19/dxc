import tkinter as tk 
master = tk.Tk()

whatever_you_do = "whatever you do will be significant..."
msg = tk.Message(master, text = whatever_you_do)
msg.config(bg='lightgreen',font = ('times',24,'italic'))
msg.pack()
tk.mainloop()
