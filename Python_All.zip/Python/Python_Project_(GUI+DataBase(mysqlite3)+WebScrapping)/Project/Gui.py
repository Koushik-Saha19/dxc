from tkinter import *
import sqlite3

root = Tk()
root.attributes('-fullscreen', True)

# Function to display the details with respect to ratings


def submit():
    r = Tk()
    con = sqlite3.connect(
        'dxc.db')
    cur = con.cursor()

    cur.execute("SELECT * FROM reviews WHERE Rating=:Rating",
                {
                    'Rating': search_by_rate.get()
                })
    records = cur.fetchall()

    cols = ['Sl. No', 'Customer Name', 'Review', 'Rating']

    for y in range(len(records)+1):
        for x in range(1, len(cols)):
            if y == 0:
                e = Entry(r, font=('Consolas 8 bold'), bg='light blue')
                e.grid(column=x+5, row=y+10)
                e.insert(0, cols[x])
            else:
                e = Entry(r)
                e.grid(column=x+5, row=y+10)
                e.insert(0, records[y-1][x])

    con.commit()
    con.close()
    r.mainloop()

# Function to display all the details


def showSubmit():
    r = Tk()
    con = sqlite3.connect(
        'dxc.db')
    cur = con.cursor()

    cur.execute("SELECT * FROM reviews")
    records = cur.fetchall()

    cols = ['Sl. No', 'Customer Name', 'Review', 'Rating']

    for y in range(len(records)+1):
        for x in range(1, len(cols)):
            if y == 0:
                e = Entry(r, font=('Consolas 8 bold'), bg='light blue')
                e.grid(column=x+50, row=y+10)
                e.insert(0, cols[x])
            else:
                e = Entry(r)
                e.grid(column=x+50, row=y+10)
                e.insert(0, records[y-1][x])

    con.commit()
    con.close()
    r.mainloop()


# Create a Search Drop Down
search_by_rate = StringVar(root)
search_by_rate.set("Select Rating")  # initial value

option = OptionMenu(root, search_by_rate, 1, 2, 3, 4, 5)
option.grid(row=0, column=1, padx=20)

# Creating a Label
search_label = Label(root, text='Select the required Rating')
search_label.grid(row=0, column=0)

# Create Submit Button
sub = Button(root, text='Show By Rating', command=submit)
sub.grid(row=1, column=0, columnspan=2, pady=10, ipadx=65, padx=10)

# Create Show all Submit Button
sub_show = Button(root, text='Show All', command=showSubmit)
sub_show.grid(row=2, column=0, columnspan=2, pady=10, ipadx=85, padx=10)

# Quit Button
sub_quit = Button(root, text='Exit', command=quit)
sub_quit.grid(row=3, column=0, columnspan=2, pady=10, ipadx=100, padx=10)

root.mainloop()
