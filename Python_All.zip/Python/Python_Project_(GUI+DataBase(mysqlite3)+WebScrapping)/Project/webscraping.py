import requests
from bs4 import BeautifulSoup as bs
import pandas as pd
import sqlite3
from tkinter import *

root = Tk()
root.attributes('-fullscreen', True)


def url_ele():
    # Getting the Url
    url = url_get.get()

    page = requests.get(url)


# print(page.content)
    soup = bs(page.content, 'html.parser')


# Function to retrive customer names from url


    def customerNames(soup):
        names = (soup.find_all('span', class_='a-profile-name'))
        cust_name = []
        for i in range(0, len(names)):

            # get_text removes all the tages and extract text
            cust_name.append(names[i].get_text())
        cust_name.pop(0)
        cust_name.pop(0)
        return cust_name


# Function to retrive reviews from url


    def allReviews(soup):
        title = list(soup.find_all(class_='review-title-content'))
        reviews = []
        for i in range(0, len(title)):
            reviews.append(title[i].get_text())
            reviews[:] = [review.rstrip('\n') for review in reviews]
        return reviews

# Function to retrive ratings from url

    def allRatings(soup):
        ratings = list(soup.find_all(class_='review-rating'))
        rating = []
        for i in range(0, len(ratings)):
            rating.append(ratings[i].get_text()[0:1])
        rating.pop(0)
        rating.pop(0)
        return rating


# Conversion of dataframe to a csv file

    try:

        df = pd.DataFrame()
        df['Customer Name'] = customerNames(soup)
        df['Review Title'] = allReviews(soup)
        df['Rating'] = allRatings(soup)
        df.to_csv(r'amazon_review.csv',
                  index=True, encoding='utf-8')


# Adding details to the database from csv file
        con = sqlite3.connect('dxc.db')
        df = pd.read_csv(
            'amazon_review.csv')
        df.to_sql('reviews', con, if_exists='append', index=False)
    except:
        print("Can't retrieve data, Please re-run the program")


url_head = Label(root, text="Amazon Product Review Aggregator")
url_head.grid(row=0, column=0)

url_get = Entry(root, width=30)
url_get.grid(row=1, column=1, padx=20)

url_lab = Label(root, text="Enter Amazon URL")
url_lab.grid(row=1, column=0)

url_btn = Button(root, text="Submit", command=url_ele)
url_btn.grid(row=4, column=0, columnspan=2, pady=10, ipadx=90, padx=10)

# Quit Button
sub_quit = Button(root, text='Exit', command=quit)
sub_quit.grid(row=5, column=0, columnspan=2, pady=10, ipadx=100, padx=10)


root.mainloop()
