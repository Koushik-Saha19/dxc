import tkinter as tk 

#Initialize
root = tk.Tk()

logo = tk.PhotoImage(file="giphy.gif")
w1 = tk.Label(root, text="Hello Tkinter",image=logo).pack(side="left")

explanation = "Hi Welcome"

w2 = tk.Label(root, justify=tk.LEFT,padx=10,text=explanation).pack(side="right")

root.mainloop()


