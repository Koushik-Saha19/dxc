import tkinter as tk 

#Initialize
root = tk.Tk()

tk.Label(root, text="Hello Tkinter",fg="red", font="Times").pack()

tk.Label(root, text="Hello Welcome",fg="light green", bg="dark green",font="Times").pack()

tk.Label(root, text="Hello Tkinter",fg="blue", bg="yellow",font="Times").pack()


root.mainloop()


