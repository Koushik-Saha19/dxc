def my_decorator(func):
    def wrapper():
        print("something is happening before function is called")
        func()
        print("something is happening after  the function called")
    return wrapper

@my_decorator
def say_whee():
    print("whee")

say_whee()