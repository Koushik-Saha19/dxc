# for n in range(1,11):
#     print(n)

# for n in 1,2,3,4,5,6,7,8,9,10:
#         print(n)

# here with range step is also given
# for n in range(1,11,2):
#     print(n)

st =  input("Enter statement")
count = 0
for c in st :
    if(c==" "):
        continue
    elif(c=='a' or c=='e' or c=='i' or c=='o' or c=='u'):
        count +=1

print(count)