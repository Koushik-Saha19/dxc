import tkinter as tk
from tkinter import filedialog, Button, mainloop, X

def fn():
    name = filedialog.askopenfilename()
    print(name)

errmsg = 'Error!'

Button(text='File Open', command=fn).pack(fill=tk.X)
mainloop()