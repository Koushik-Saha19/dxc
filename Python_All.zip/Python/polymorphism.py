def sum(n,m=10):
    s = 0
    for val in range(n,m+1):
        s += val

    print(s)



sum(2)



