lst = [int(s) for s in input().split()]
l = len(lst)
flag = True

for i in range(l): 
  flag = True
  for j in range(l):
    if (lst[i] == lst[j] and i != j):
      flag = False
      break
  if (flag):
    print(lst[i])
      
