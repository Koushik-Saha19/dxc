x = input()
y = x.split()
n = int(y[0])
m = int(y[1])
a = [["." for x in range(m)] for y in range(n)] 
for i in range(n):
  for j in range(m):
    if(i%2==0):
      if(j%2!=0):
        a[i][j] = "*"
    if(i%2!=0):
      if(j%2==0):
        a[i][j] = "*"
      
      
for i in range(n):
  for j in range(m):
      print(a[i][j],end=" ")
  print()

