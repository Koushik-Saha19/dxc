def sum(*nums):
    s = 0
    for num in nums:
        s += num
    return s  

#here we can pass any number of argument in the function
print(sum(3,4))
print(sum(3,4,5))
print(sum(3,4,5,6))
print(sum(3,4,5,6,7,8))