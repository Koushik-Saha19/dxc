print("Hi Welcome")
x=9.9
print(type(x))