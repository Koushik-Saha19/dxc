n = int(input())
a = [["." for x in range(n)] for y in range(n)] 
for i in range(n):
  for j in range(n):
    if(i==j):
      a[i][j] = "*"
    if(j==(int(n/2)+1)):
      a[i][j] = "*"
    if(i==(int(n/2)+1)):
      a[i][j] = "*" 
    if(j==n-i-1):
      a[i][j] = "*"
      
      
for i in range(n):
  for j in range(n):
      print(a[i][j],end=" ")
  print()
