entry = 0
sum = 0
print("Enter number, negative number will exit")

while True:
    entry = int(input())
    if(entry<0):
        continue
    sum +=entry


print("Sum=", sum)