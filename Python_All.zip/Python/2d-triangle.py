n = int(input())
a = [[0 for x in range(n)] for y in range(n)] 
for i in range(n):
  for j in range(n):
    if(j==n-i-1):
       a[i][j]=1
    if(i>n-j-1):
      a[i][j]=2
     
      
      
for i in range(n):
  for j in range(n):
      print(a[i][j],end=" ")
  print()
