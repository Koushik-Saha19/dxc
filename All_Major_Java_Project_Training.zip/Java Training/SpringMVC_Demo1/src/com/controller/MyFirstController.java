package com.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyFirstController {

	@RequestMapping("/Jason")
	public String gg(){
		return "watch";
	}
	
	@RequestMapping("/Eoin")
	public String gaag(){
		return "ball";
	}
	
}
