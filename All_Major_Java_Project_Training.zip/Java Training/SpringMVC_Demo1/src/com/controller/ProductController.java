package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dxc.pms.model.Product;
import com.dxc.pms.service.ProductService;

@Controller
public class ProductController {

	@Autowired
	ProductService productService;
	@RequestMapping("/productSave")
	public ModelAndView productSave(Product product) {
		
		System.out.println("Inside Controller" + product);
		
		productService.addProduct(product);
		return new ModelAndView("success","product",product);
	}
	
	
	
	
}
