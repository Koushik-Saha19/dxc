package com.dxc.pms.dao;

import com.dxc.pms.model.Product;

public class ProductDAOImpl implements ProductDAO {

	@Override
	public boolean addProduct(Product product) {
		
		System.out.println("Inside DAO :" + product);
		return true;
	}

	
}
