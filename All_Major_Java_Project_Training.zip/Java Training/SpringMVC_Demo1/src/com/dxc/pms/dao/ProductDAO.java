package com.dxc.pms.dao;

import com.dxc.pms.model.Product;

public interface ProductDAO {

	public boolean addProduct(Product product);
}
