package com.dxc.pms.service;

import com.dxc.pms.model.Product;

public interface ProductService {

	public boolean addProduct(Product product);
	
}
