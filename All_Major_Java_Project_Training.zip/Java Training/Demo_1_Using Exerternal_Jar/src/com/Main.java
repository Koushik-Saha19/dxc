package com;
//This App class is imported from jar file given by sir,
//we didn't created the the App class....here the jar file is acting as library....
//That we don't have to make any class...if anybody is 
import com.ahmed.App;

public class Main {

	
	
	public static void main(String[] args) {
		App p = new App();
		System.out.println(p.message("Hi "));
	}
}

