package com;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoController {

	@Autowired
	ConfigProps configProps;

	@RequestMapping("/displayProperties")
	public String test() {
		return "********Team Name***********" + configProps.getName() + ":password is :" + configProps.getPassword();
	}

}
