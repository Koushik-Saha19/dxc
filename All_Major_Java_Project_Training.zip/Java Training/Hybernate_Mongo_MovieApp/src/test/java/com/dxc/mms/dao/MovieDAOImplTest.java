package com.dxc.mms.dao;

import java.util.List;

import com.dxc.mms.dao.MovieDAOImpl;
import com.dxc.mms.model.Movie;

import junit.framework.TestCase;

public class MovieDAOImplTest extends TestCase {

	MovieDAOImpl impl;
	public MovieDAOImplTest(String name) {
		super(name);
	}

	protected void setUp() throws Exception {
		impl = new MovieDAOImpl();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	
	public void testGetMovie() {
		Movie movie1= new Movie(123, "Calculator1", 2890, "Ravi");
		impl.addMovie(movie1);
		Movie product2= impl.getMovie(122);
		assertEquals(movie1.getMovieId(),product2.getMovieId());
	}

	public void testGetAllProducts() {
		Movie movie = new Movie(908,"HBpencil1",112,"Ram");
		List<Movie> allMovie1 = impl.getAllMovies();
		impl.addMovie(movie);
		List<Movie> allMovie2 = impl.getAllMovies();
		assertSame(allMovie2.size(), allMovie1.size()+1);
	}

	public void testAddMovie() {
		Movie movie = new Movie(909,"charger",112,"sam");
		List<Movie> allMovie1 = impl.getAllMovies();
		impl.addMovie(movie);
		List<Movie> allMovie2 = impl.getAllMovies();
		assertNotSame(allMovie2.size(), allMovie1.size());
	}

	public void testDeleteMovie() {
		int movieId = 107;
		List<Movie> allMovie1 = impl.getAllMovies();
		impl.deleteMovie(movieId);
		List<Movie> allMovie2 = impl.getAllMovies();
		assertNotSame(allMovie1.size()-1, allMovie2.size());
	}

	public void testUpdateMovie() {
		Movie movie1 = new Movie(108,"bat",112,"rahul");
		impl.addMovie(movie1);
		Movie movie2 = new Movie(108,"ball",115,"rahul");
		impl.updateMovie(movie2);
		assertNotSame(movie1.getMovieName(), movie2.getMovieName());
	}

	public void testIsMovieExists() {
		Movie movie1= new Movie(3, "pencil1", 12, "Mohan");
		impl.addMovie(movie1);
		assertEquals(true, impl.isMovieExists(movie1.getMovieId()));
	}

}
