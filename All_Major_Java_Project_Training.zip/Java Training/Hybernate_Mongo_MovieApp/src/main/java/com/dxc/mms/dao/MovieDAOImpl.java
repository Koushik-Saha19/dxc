package com.dxc.mms.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dxc.mms.model.Movie;
import com.dxc.mms.util.HibernateUtil;
import com.dxc.mms.model.Movie;
import com.dxc.mms.model.Movie;

public class MovieDAOImpl implements MovieDAO {

	SessionFactory sf = HibernateUtil.getSessionFactory();
	
	public Movie getMovie(int movieId) {
		Session session = sf.openSession();
		Movie movie = (Movie)session.get(Movie.class, movieId);	
		return movie;
	}

	public List<Movie> getAllMovies() {
		Session session = sf.openSession();
		Query query = session.createQuery("from Movie");
		return query.list();	
		
	}

	public void addMovie(Movie movie) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(movie);
		transaction.commit();
		session.close();
		System.out.println(movie.getMovieName() + "saved successfully");

	}

	public void deleteMovie(int movieId) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		Movie movie =new Movie();
		movie.setMovieId(movieId);
		session.delete(movie);
		transaction.commit();
	    session.close();

	}

	public void updateMovie(Movie newMovie) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();	
		session.update(newMovie);
		transaction.commit();
		session.close();
	}

	public boolean isMovieExists(int movieId) {
		Session session = sf.openSession();
		Movie product = (Movie)session.get(Movie.class,movieId);
		if(product==null)
			return false;
		else
			return true;
		
	}

}
