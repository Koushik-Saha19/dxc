package com.dxc.mms.dao;

import java.util.List;

import com.dxc.mms.model.Movie;


public interface MovieDAO {
	public Movie getMovie(int movieId);
	public List<Movie> getAllMovies();
	public void addMovie(Movie movie);
	public void deleteMovie(int movieId);
	public void updateMovie(Movie movie);
	public boolean isMovieExists(int movieId);
}