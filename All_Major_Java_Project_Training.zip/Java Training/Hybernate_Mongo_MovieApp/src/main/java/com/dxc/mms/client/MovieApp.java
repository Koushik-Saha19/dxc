package com.dxc.mms.client;

import java.util.Scanner;

import com.dxc.mms.dao.MovieDAO;
import com.dxc.mms.dao.MovieDAOImpl;
import com.dxc.mms.model.Movie;

public class MovieApp {
	MovieDAO movieDAO;
	int choice = 0;
	int movieId;
	String movieName;
	int budget;
	String directorName;
	Scanner scanner = new Scanner(System.in);

	public MovieApp() {

		this.movieDAO = new MovieDAOImpl();

	}

	public void launchMovieApp() {

		while (true) {
			System.out.println("M E N U ");
			System.out.println("1. Add The movies : ");
			System.out.println("2. Get All The movies : ");
			System.out.println("3. Get movies by id : ");
			System.out.println("4. Delete movie by id : ");
			System.out.println("5. Update movie by id : ");
			System.out.println("6. E X I T");

			System.out.println("Please enter your choice : (1-6)");
			choice = scanner.nextInt();

			switch (choice) {
			case 1:
				Movie product = takeMovieInput();
				if (!movieDAO.isMovieExists(product.getMovieId())) {
					movieDAO.addMovie(product);
				} else {
					System.out.println("Product already exists with product id : " + movieId);
				}
				break;
			case 2:
				System.out.println(movieDAO.getAllMovies());
				break;
			case 3:
				System.out.println("Please enter product id to search :");
				movieId = scanner.nextInt();
				if (movieDAO.isMovieExists(movieId)) {
					Movie searchedProduct = movieDAO.getMovie(movieId);
					System.out.println(searchedProduct);
				} else {
					System.out.println("Product Id not found");
				}
				break;
			case 4:
				System.out.println("Please enter product id to delete :");
				movieId = scanner.nextInt();
				if (movieDAO.isMovieExists(movieId)) {
					movieDAO.deleteMovie(movieId);
					System.out.println("Product deleted successfully");
				} else {
					System.out.println("Product Id not found");
				}
				break;
			case 5:
				System.out.println("Welcome to product app category : ");
				Movie productToUpdate = takeMovieInput();
				if (movieDAO.isMovieExists(productToUpdate.getMovieId())) {
					movieDAO.updateMovie(productToUpdate);
					System.out.println("Your product updated successfully ");
				} else {
					System.out.println("Product id does not exists");
				}
				break;
			case 6:
				System.out.println("Thanks for using my app");
				System.exit(0);
			default:
				System.out.println(" Please enter (1-3)");
			}
		}
	}

	private Movie takeMovieInput() {
		System.out.println("Please enter movie id :");
		movieId = scanner.nextInt();
		System.out.println("Please enter movie name :");
		movieName = scanner.next();
		System.out.println("Please enter movie budget :");
		budget = scanner.nextInt();
		System.out.println("Please enter movie director :");
		directorName = scanner.next();

		Movie product = new Movie(movieId, movieName, budget, directorName);
		return product;
	}
}
