package com.dxc.mms.client;

import com.dxc.mms.client.MovieApp;

public class Main {

	public Main() {
	}

	public static void main(String[] args) {
		System.out.println("###########Movie J D B C  APP########");
		MovieApp app = new MovieApp();
		app.launchMovieApp();
	}
}
