package com.dxc.client.myFirstMaven;

import junit.framework.TestCase;

public class AddNumbersTest extends TestCase {

	public void testSum() {
		AddNumbers numbers = new AddNumbers();
		int res = numbers.sum(1, 1);
		assertEquals(2, res);
	}
	
	public void testSum1() {
		AddNumbers numbers = new AddNumbers();
		int res = numbers.sum(2, 3);
		assertEquals(5, res);
	}
	
	
}
