package com;

public class Subject {

	private String subject;
	
	public Subject() {
		// TODO Auto-generated constructor stub
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	@Override
	public String toString() {
		return "Subject [subject=" + subject + "]";
	}
	
	
	
}
