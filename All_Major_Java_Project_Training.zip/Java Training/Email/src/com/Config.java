package com;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Config {

	@Bean
	public Email getEmail() {
		return new Email();
		
	}
	
	@Bean
	public To getTo() {
		return new To();
		
	}
	@Bean
	public From getFrom() {
		return new From();
	}
	@Bean
	public Body getBody() {
		return new Body();
	}
	@Bean
	public Subject getSubject() {
		return new Subject();
	}
	
}

