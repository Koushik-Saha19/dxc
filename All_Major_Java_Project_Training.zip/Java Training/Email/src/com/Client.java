package com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Client {

	
	public static void main(String[] args) {
		
		ApplicationContext context = new AnnotationConfigApplicationContext(Config.class);
		Email e = (Email)context.getBean(Email.class);
		From f = (From)context.getBean(From.class);
		Subject s = (Subject)context.getBean(Subject.class);
		Body b = (Body)context.getBean(Body.class);
		To t = (To)context.getBean(To.class);
		
		
		t.setToEmail("abc.gmail.com");
		t.setToName("Joe");
		f.setFromEmail("xyz@gmail.com");
		f.setFromName("Jason");
		s.setSubject("wish");
		b.setBody("Hi, How r u?");
//		e.setTo(t);
//		e.setFrom(f);
//		e.setSubject(s);
//		e.setBody(b);...........we don,t have to use this 4 line of code ..if we use "@Autowired" in Email class...
		
		System.out.println(e);
	}
}

