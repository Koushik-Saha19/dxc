package com;

public class Body {

	private String body;
	
	public Body() {
		// TODO Auto-generated constructor stub
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	@Override
	public String toString() {
		return "Body [body=" + body + "]";
	}
	
	
}
