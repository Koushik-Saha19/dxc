package com.dxc.jc.client;

import java.util.Scanner;

import com.dxc.jc.dao.userDAO;
import com.dxc.jc.dao.userDAOImpl;
import com.dxc.jc.model.user;

public class userApp {
	userDAO userDAO;
	int choice = 0;
	
	String userName;
	String password;
	int percentage;
	
	Scanner scanner = new Scanner(System.in);
public userApp() {
	
		this.userDAO = new userDAOImpl();//here object type is ProductDAO but it is referring to ProductDAOImpl class...
}





public void launchuserApp() {

		while(true) {
			System.out.println("MENU");
			System.out.println("1. Display All Training Records");
			System.out.println("2. Display Records one by One and update the percentage");
			System.out.println("3. E X I T ");
		
			
			
			System.out.println("Please enter your choice: (1-6)");
			
			choice = scanner.nextInt();
			
			switch (choice) {
		
			case 1:
				userDAO.getAllTraingRecord();
				break;
			case 2:
				System.out.println("please enter username & password");
				String username = scanner.next();
				String password = scanner.next();

				if (userDAO.isProductExist(productId)) {
					user searchproduct = userDAO.showOneBYOne(productId);
					System.out.println(searchproduct);
				}
				else {
					System.out.println("Product Id not found");
				}
				break;
			case 4:
				System.out.println("please enter product id to delete");
				productId = scanner.nextInt();
	
				if (productDAO.isProductExist(productId)) {
					productDAO.deleteProduct(productId);
					System.out.println("Product deleted successfully");
				}
				else {
					System.out.println("Product Id not found");
				}
				break;
			case 5:
				System.out.println("Welcome to update process");
				Product productToUpdate = takeProductInput();
				if (productDAO.isProductExist(productToUpdate.getProductId())) {
					productDAO.updateProduct(productToUpdate);
					System.out.println("Your product updated successfully");
				}	else {
					System.out.println("Product Id not found");
				}
				break;
			case 6:
				System.out.println("Thanks for using my app");
				System.exit(0);
			default:
				System.out.println("R U drunk milk. Please enter (1-3)");
			}
		}
}
private user takeProductInput() {
	
	System.out.println("Please enter prduct id");
	 userName = scanner.next();
	System.out.println("Please enter prduct Name");
	 password = scanner.next();
	Product product = new Product(productId, productName,quantityOnHand,price);
	return product;
}
}
