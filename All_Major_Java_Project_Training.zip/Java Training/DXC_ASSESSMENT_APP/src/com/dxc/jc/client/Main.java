package com.dxc.jc.client;

import com.dxc.jc.model.user;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		user u1 = new user();
		u1.validation();
		
	}

}
