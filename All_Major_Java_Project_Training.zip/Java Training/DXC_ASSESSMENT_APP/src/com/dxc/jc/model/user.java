package com.dxc.jc.model;

import java.util.Scanner;

import com.dxc.jc.dao.userDAOImpl;


public class user {

	String username;
	String password ;
	int sap_id;
	String EmpName;
	String stream;
	
	Scanner sc = new Scanner(System.in);
	public void validation() {
		System.out.println("Enter username:");
		 username = sc.next();
		System.out.println("Enter password:");
		 password = sc.next();
		
		userDAOImpl userDAOImpl = new userDAOImpl();
		userDAOImpl.validation(username,password);
		
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		result = prime * result + ((username == null) ? 0 : username.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		user other = (user) obj;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (username == null) {
			if (other.username != null)
				return false;
		} else if (!username.equals(other.username))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "user [sap_id=" + sap_id + ", EmpName=" + EmpName + ", stream=" + stream + "]";
	}
	
	public user(int sap_id, String empName, String stream) {
		
		this.sap_id = sap_id;
		EmpName = empName;
		this.stream = stream;
	}
	public user() {
		
	}
	
	
}
