package com.dxc.jc.dao;

import java.util.List;

import com.dxc.jc.model.user;
import com.dxc.jc.model.user;

public interface userDAO {

	public boolean validation(String username,String password);
	public void getAllTraingRecord();
	public user showOneBYOne();
	
}
