package com.dxc.jc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.dxc.jc.dbcon.DBConnection;
import com.dxc.jc.model.user;


public class userDAOImpl implements userDAO{

	Connection connection = DBConnection.getConnection();
	private static final String FETCH_USERNAME = "select * from users where username = ? and password = ?";
	private static final String FETCH_ALLTRAINING_RECORDS = "select * from users";
	
	@Override
	public boolean validation(String username,String password) {
		// TODO Auto-generated method stub
		
			boolean userExists = false;
			PreparedStatement preparedStatement;
			try {
				preparedStatement = connection.prepareStatement(FETCH_USERNAME);
				preparedStatement.setString(1, username);
				preparedStatement.setString(2, password);
				ResultSet res = preparedStatement.executeQuery();
				if(res.next()) {
					userExists = true;
					System.out.println("User successfully authenticated.");
					return true;
				}
				else {
					System.out.println("User name cannot be authenticated.");
					return false;
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
				
			}
			
	}


	@Override
	public void getAllTraingRecord() {
		// TODO Auto-generated method stub
		try {
			Statement stat = connection.createStatement();
			ResultSet res = stat.executeQuery(FETCH_ALLTRAINING_RECORDS);
			
			while (res.next()) {
				System.out.println(res.getInt(1));
				System.out.println(res.getString(2));
				System.out.println(res.getString(3));
				System.out.println(res.getInt(4));
			}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


	@Override
	public user showOneBYOne() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}
