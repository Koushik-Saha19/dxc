package com.dxc.hms.dao;

import java.util.List;

import com.dxc.hms.model.Doctor;


public interface DoctorDAO {

	public Doctor getDoctor(int doctorId);
	public List<Doctor> getAllDoctor();
	public boolean addDoctor(Doctor doctor);
	public boolean deleteDoctor(int doctorId);
	public boolean updateDoctor(Doctor doctor);
	public boolean isDoctorExists(int doctorId);
	public List<Doctor> getDoctorByName(String doctorName);
}
