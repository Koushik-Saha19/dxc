package com.dxc.hms.model;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="DoctorData")
public class Doctor {

	@Id
	private int doctorId;
	
	@Column(name="DoctorName")
	private String doctorName;
	
	@Column(name="fees")
	private int fees;
	
	@Embedded
	private Hospital hospital;
	
	public Doctor() {
		// TODO Auto-generated constructor stub
	}

	public Doctor(int doctorId, String doctorName, int fees, Hospital hospital) {
		super();
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.fees = fees;
		this.hospital = hospital;
	}

	public int getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public int getFees() {
		return fees;
	}

	public void setFees(int fees) {
		this.fees = fees;
	}

	public Hospital getHospital() {
		return hospital;
	}

	public void setHospital(Hospital hospital) {
		this.hospital = hospital;
	}

	@Override
	public String toString() {
		return "Doctor [doctorId=" + doctorId + ", doctorName=" + doctorName + ", fees=" + fees + ", hospital="
				+ hospital + "]";
	}
	
	
}
