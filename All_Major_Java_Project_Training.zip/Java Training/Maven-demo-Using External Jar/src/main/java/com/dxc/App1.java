package com.dxc;

import com.joe.App;

public class App1 
{
    public static void main( String[] args )
    {
    
    	App app = new App();
        System.out.println(app.message("Hi") );
    }
}
