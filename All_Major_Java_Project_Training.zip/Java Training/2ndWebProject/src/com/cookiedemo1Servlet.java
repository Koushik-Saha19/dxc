package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/cookiedemo1Servlet")
public class cookiedemo1Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public cookiedemo1Servlet() {
        super();
        
       
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uname = request.getParameter("username");
		String pwd = request.getParameter("password");
		
		Cookie allCookie[] = request.getCookies();
		boolean alreadyVisited = false;
		if(allCookie!=null) {
			for(Cookie c: allCookie) {
				if(c.getName().equals(uname)) {
					alreadyVisited=true;
					break;
				}
			}
		}
		if(alreadyVisited) {
			response.getWriter().println("<h1>Welcome to checkServlet,you have already visited </h1>");
		}
		else {
			response.getWriter().println("<h1>Welcome to checkServlet,You are first visitor</h1>");
			Cookie cookie = new Cookie("uname",uname);
			response.addCookie(cookie);
		}
	}

}
