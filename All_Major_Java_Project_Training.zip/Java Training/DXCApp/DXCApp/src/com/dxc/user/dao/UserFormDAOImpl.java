package com.dxc.user.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dxc.pms.dbcon.DBConnection;
import com.dxc.user.model.UserForm;

public class UserFormDAOImpl implements UserFormDAO {

	Connection connection = DBConnection.getConnection();
	
	
	public UserFormDAOImpl() {
		
		
	}

	@Override
	public void addUser(UserForm userForm) {
		
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("insert into userform values(?,?,?,?)");
			preparedStatement.setString(1, userForm.getUsername());
			preparedStatement.setString(2, userForm.getPassword());
			preparedStatement.setString(3, userForm.getFullName());
			preparedStatement.setString(4, userForm.getGender());

			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	@Override
	public boolean validateUser(String username, String password) {
		return false;
	
		

	}
	
	public boolean isUserNameExist(String username) {
		
		boolean usernameExists = false;
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("select * from userform where username = ?");
			preparedStatement.setString(1, username);

			ResultSet res = preparedStatement.executeQuery();
			if (res.next()) {
				usernameExists = true;
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return usernameExists;
		
		
	}

}
