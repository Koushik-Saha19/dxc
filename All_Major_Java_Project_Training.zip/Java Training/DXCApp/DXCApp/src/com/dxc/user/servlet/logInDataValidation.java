package com.dxc.user.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dxc.user.dao.UserFormDAO;
import com.dxc.user.dao.UserFormDAOImpl;


public class logInDataValidation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public logInDataValidation() {
        super();
        
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		UserFormDAO u1 = new UserFormDAOImpl();
		String username = request.getParameter("username");
		String password = request.getParameter("password");

		if(u1.isUserNameExist(username) && u1.isUserNameExist(password)) {
			response.getWriter().println("<h1>You are successfully Loged In</h1>");
		}
		else {
			response.getWriter().println("</br></br><h1><font color='red'>You User Name or Password is wrong...if You don't have account please</font><a href='registrationForm.html'>Register</a></h1>");
		}
	}

}
