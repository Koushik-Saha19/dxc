package com.dxc.mms.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.annotation.DeterminableImports;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.dxc.mms.model.Movie;
import com.mongodb.WriteResult;
import com.mongodb.client.result.DeleteResult;


@Repository
public class MovieDAOImpl implements MovieDAO {

	@Autowired
	MongoTemplate mongoTemplate;
	
	@Override
	public List<Movie> getAllMovie() {
		
		return mongoTemplate.findAll(Movie.class);
	}

	@Override
	public boolean addMovie(Movie movie) {
		mongoTemplate.save(movie);
		return true;
	}

	@Override
	public boolean deleteMovie(int movieId) {
		
		Movie movie = new Movie();
		movie.setMovieId(movieId);
		
		DeleteResult deleteResult = mongoTemplate.remove(movie);

		long rowsAffected = deleteResult.getDeletedCount();
		if(rowsAffected==0)
			return false;
		else
			return true;
	}

	@Override
	public boolean updateMovie(Movie movie) {
		mongoTemplate.save(movie);
		return true;
		
	}

	@Override
	public Movie getMovieById(int movieId) {
		
	 return mongoTemplate.findById(movieId, Movie.class,"movie");
	}

	@Override
	public boolean isMovieExist(int movieId) {
		
		Movie movie = mongoTemplate.findById(movieId, Movie.class,"movie");
		if(movie==null)
			return false;
		else 
			return true;
					
	}

}
