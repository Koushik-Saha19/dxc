package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.dxc.pms.model.Product;
import com.dxc.pms.service.ProductService;

@RestController
@RequestMapping("product")
@CrossOrigin(origins= {"http://localhost:3000","http://localhost:4200"})
public class ProductController {

	@Autowired
	ProductService productService;
	

	//To fetch all products
	@GetMapping
	public List<Product> getAllProduct() {
		System.out.println("Fetching all products" );
		return productService.getProducts();
	}
	

	//Getting a single product
	@GetMapping("/{productId}")
	public Product getProduct(@PathVariable("productId")int productId) {
		System.out.println("Get product 1 called " + productId);
		return productService.getProduct(productId);
	}
	
	//to delete product
	@DeleteMapping("/{productId}")
	public boolean deleteProduct(@PathVariable("productId")int productId) {
		System.out.println("delete product called " );
		return productService.deleteProduct(productId);
	}
	
	
	
	
//	@RequestMapping("/getProduct/{productId}/orders/{oId}")
//	public Product getProduct(@PathVariable("productId")int productId,@PathVariable("oId")int oId) {
//		System.out.println("Get product 2 is called with productId and orderId " + productId + "and " + oId);
//		return productService.getProduct(productId); 
//	}
//	
//	
	@PostMapping()
	public boolean saveProduct(@RequestBody Product product) {
		System.out.println("saving product");
		return productService.addProduct(product);
	}
	@PutMapping()
	public boolean updateProduct(@RequestBody Product product) {
		System.out.println("update a product called");
		return productService.updateProduct(product);
	}
}
	
	
	
	

