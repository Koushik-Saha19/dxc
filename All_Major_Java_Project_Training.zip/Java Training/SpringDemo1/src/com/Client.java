package com;

public class Client {

	
	public static void main(String[] args) {
		
		Employee e = new Employee();
		e.setEmployeeName("Joe");
		System.out.println(e.getEmployeeName());
	}
}
