package com;

public class Project {

	private String project;
	
	public Project() {
		// TODO Auto-generated constructor stub
	}

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	@Override
	public String toString() {
		return "Project [project=" + project + "]";
	}
	
}
