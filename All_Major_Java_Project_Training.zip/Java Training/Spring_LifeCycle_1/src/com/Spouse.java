package com;

public class Spouse {

	private String spouse;

	public Spouse() {
		// TODO Auto-generated constructor stub
	}
	public String getSpouse() {
		return spouse;
	}

	public void setSpouse(String spouse) {
		this.spouse = spouse;
	}
	@Override
	public String toString() {
		return "Spouse [spouse=" + spouse + "]";
	}
	
	
}
