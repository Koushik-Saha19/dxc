package com;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/nameServlet")
public class nameServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public nameServlet() {
        super();
        
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String name = request.getParameter("name");
		HttpSession sesssion = request.getSession();
		
		sesssion.setAttribute("myname", name);
		
		response.getWriter().println("<h2>Total Question:5</h2>");
		response.getWriter().println("<h2>Total Marks:50</h2>");
		response.getWriter().println("<h2><a href='BeginTest'>Begin Test</h2>");
		
	}

}
