package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/BeginTest")
public class BeginTest extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public BeginTest() {
        
            }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		HttpSession session = request.getSession();
		String name = (String) session.getAttribute("myname");
		
		response.getWriter().println("<h1>Welcome " + name + ", Please Begin the Test</h1>");
		response.getWriter().println("<h1><a href='question1.html'>Start Test</a></h1>");
			}

}
