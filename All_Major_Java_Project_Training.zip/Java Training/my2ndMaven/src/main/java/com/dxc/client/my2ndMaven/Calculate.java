package com.dxc.client.my2ndMaven;

public class Calculate {

	
	public int multiply(int n1, int n2) {
		return n1*n1;
	}
}
