package com.dxc.client.my2ndMaven;

import junit.framework.TestCase;

public class CalculateTest extends TestCase {

	public CalculateTest(String name) {
		//super(name);
		
	}

	protected void setUp() throws Exception {
		//super.setUp();
		System.out.println("Set Up called");
	}

	protected void tearDown() throws Exception {
		//super.tearDown();
		
	}
	
	public void testMultiply1() {
		
	}

  public void testMultiply2() {
		
	}

}
