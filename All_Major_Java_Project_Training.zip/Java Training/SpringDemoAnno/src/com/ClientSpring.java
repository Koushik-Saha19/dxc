package com;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ClientSpring {

	
	public static void main(String[] args) {
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		Employee e = (Employee)context.getBean(Employee.class);
		Employee e1 = (Employee)context.getBean(Employee.class);
		Employee e2 = (Employee)context.getBean(Employee.class);
		
		
//		Address a = (Address)context.getBean(Address.class);
	
		
//		e.setEmpId(94);
//		e.setEmpName("Eoin Morgan");
//		e.setSalary(98000);
//		
//		
//		a.setCity("Jaipur");
//		a.setState("Rajasthan");
//		
//		e.setaddress(a);
		
		System.out.println(e);
		context.registerShutdownHook();
	}
}
