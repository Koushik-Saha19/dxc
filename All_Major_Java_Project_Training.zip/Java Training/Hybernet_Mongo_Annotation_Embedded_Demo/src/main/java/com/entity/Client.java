package com.entity;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dxc.pms.util.HibernateUtil;

public class Client {

	public static void main(String[] args) {
		
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		
		
		BillAmount bill1 = new BillAmount(1991,100,100,9700);
		BillAmount bill2 = new BillAmount(1992,50,100,9700);
		BillAmount bill3 = new BillAmount(1993,75,150,9705);
		
		Set<BillAmount> allBills = new HashSet<BillAmount>();
		allBills.add(bill1);
		allBills.add(bill2);
		allBills.add(bill3);
		allBills.add(new BillAmount(1994,100,200,9000));
		
		
		Customer customer = new Customer("Joe",allBills);
		
		session.save(customer);
		transaction.commit();
		
		System.out.println("It is working");
		
	}
}
