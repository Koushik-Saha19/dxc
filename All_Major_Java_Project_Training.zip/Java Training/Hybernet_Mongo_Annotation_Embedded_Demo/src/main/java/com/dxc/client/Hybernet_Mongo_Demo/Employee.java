package com.dxc.client.Hybernet_Mongo_Demo;

public class Employee {

}
