package com.dxc.client.Hybernet_Mongo_Demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.ogm.cfg.OgmConfiguration;

import com.dxc.model.Customer;
import com.dxc.model.Employee;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       OgmConfiguration cfg = new OgmConfiguration();
       cfg.configure();
       
       SessionFactory factory = cfg.buildSessionFactory();
       Session session1 = factory.openSession();
       Session session2 = factory.openSession();
        Transaction transaction1 = session1.beginTransaction();
        Transaction transaction2 = session2.beginTransaction();
        
        
        Employee employee = new Employee(191888887, "MSD", "India", 999999);
        
        Customer customer = new Customer(7111190, "Ben", "England", 9805550);
        
        session1.save(employee);
        session2.save(customer);
        transaction1.commit();
        transaction2.commit();
        
        System.out.println("Data stored in momgodb");
    }
}
