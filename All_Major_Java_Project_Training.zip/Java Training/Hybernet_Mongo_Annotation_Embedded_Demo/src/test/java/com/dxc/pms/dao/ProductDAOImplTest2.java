package com.dxc.pms.dao;

import junit.framework.TestCase;

public class ProductDAOImplTest2 extends TestCase {

	public ProductDAOImplTest2(String name) {
		super(name);
	}

	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testGetAllProductsString() {
		fail("Not yet implemented");
	}

}
