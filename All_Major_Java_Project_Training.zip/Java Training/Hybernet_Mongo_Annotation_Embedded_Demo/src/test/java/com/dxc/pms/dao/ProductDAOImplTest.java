package com.dxc.pms.dao;



import java.util.List;

import com.dxc.pms.model.Product;

import junit.framework.TestCase;

public class ProductDAOImplTest extends TestCase {

	
	ProductDAOImpl impl;
	
	public ProductDAOImplTest(String name) {
		super(name);
	}

	protected void setUp() throws Exception {
		impl = new ProductDAOImpl();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	
	
	
	
	
	public void testGetProduct() {
		Product product1= new Product(124, "Calculator1", 2890, 590);
		impl.addProduct(product1);
		Product product2= impl.getProduct(124);
		assertEquals(product1.getProductId(),product2.getProductId());
		
		
	}

	public void testGetAllProducts() {
		Product product = new Product(908,"HBpencil1",112,109);
		List<Product> allProduct1 = impl.getAllProducts();
		impl.addProduct(product);
		List<Product> allProduct2 = impl.getAllProducts();
		assertSame(allProduct2.size(), allProduct1.size()+1);
		
	}

	public void testAddProduct() {
		Product product = new Product(222,"headphone2",129,1234);
		List<Product> allProduct1 = impl.getAllProducts();
		impl.addProduct(product);
		List<Product> allProduct2 = impl.getAllProducts();
		assertNotSame(allProduct2.size(), allProduct1.size());
	}

	public void testDeleteProduct() {
		
		int productId = 1061;
		List<Product> allProduct1 = impl.getAllProducts();
		impl.deleteProduct(productId);
		List<Product> allProduct2 = impl.getAllProducts();
		assertSame(allProduct1.size()-1,allProduct2.size());
	}

	public void testUpdateProduct() {
		
		Product product1 = new Product(1063,"mouse5",10,238);
		impl.addProduct(product1);
		Product product2 = new Product(1063,"mouse6",10,2509);
		impl.updateProduct(product2);
		assertNotSame(product1.getProductName(),product2.getProductName());
	}

	
	
	
	public void testIsProductExists() {
		Product product1= new Product(3, "pencil1", 12, 100);
		impl.addProduct(product1);
		assertEquals(true, impl.isProductExists(product1.getProductId()));
	}
	
  public void testGetAllProductNames() {
		impl.getAllProductNames();
		assertEquals(true,true);
		
	}

}
