package com.dxc.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dxc.pms.dbcon.DBConnection;


public class random_number extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public random_number() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		
//		Connection connection = DBConnection.getConnection();
//		RandomNumberGenerator rd = new RandomNumberGenerator();
		
//		try {
//			Statement stat = connection.createStatement();
//			for(int i=0; i<3;i++) {
//			ResultSet res = stat.executeQuery("select from qusetions where questionNo =" + rd.random());
//		    response.getWriter().println(res.getString(2));
//				
//			}
//			
//			
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		
		
	}

}
