

package com.dxc.servlet;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class RandomNumberGenerator {

	public int[] random() {
		int num[] = new int[3];
		ArrayList numbers = new ArrayList();
		for(int i = 0; i < 10; i++){
			numbers.add(i+1);
		}
		Collections.shuffle(numbers);
		for(int j =0; j < 3; j++){
			num[j] = (int) numbers.get(j);
		}
		System.out.println(Arrays.toString(num));
		return num;
	
	}
}
