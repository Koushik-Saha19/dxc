package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Exercise1Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public Exercise1Servlet() {
        super();
        
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String name = request.getParameter("Name");
		
		String[] alert = request.getParameterValues("name1");
		
		if(alert == null) {
			response.getWriter().println("<h1>You haven't selected alert by, so no Nothing!!</h1>");
		}
		else {
			for(String s:alert) {
			response.getWriter().println("<font color="+ s + "><h1>Hello  " + name + "</h1></font>");
			}
		}
	}

}
