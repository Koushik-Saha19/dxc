package com;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class A_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public A_Servlet() {
        
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("Go");
		
		
		
		response.getWriter().println("Apple");
		String uname = request.getParameter("uname");
		if(uname.startsWith("A")) {
			response.sendRedirect("B_Servlet");
		}
	}

}
