package servletPractice;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class demo1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   int counter = 0;
    public demo1() {
       
       counter = 100;
    }
    public void init() {
    	System.out.println("1. INIT CALLED");
    }
public void display() {
	System.out.println("Display Called");
}
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		System.out.println("2.INIT WITH CONFIG");
		
	}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("3.SERVICE CALLED");
		
		counter++;
		response.getWriter().println("<h1>Welcome to DXC</h1>");
		response.getWriter().println("<h1>You are user number</h1>" + counter);
		response.getWriter().println("<h1><a href = 'product.html'>Add Product</a></h1>");
		response.getWriter().println("<h1><a href = 'delete.html'>Delete Product</a></h1>");
		response.getWriter().println("<h1><a href = 'update.html'>Update Product</a></h1>");
		response.getWriter().println("<h1><a href = 'getAllProduct'>Get All The Product</a></h1>");
		response.getWriter().println("<h1><a href = 'tc.html'>T&C</a></h1>");
	}
}