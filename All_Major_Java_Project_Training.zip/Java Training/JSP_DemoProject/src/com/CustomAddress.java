package com;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class CustomAddress extends TagSupport {
	
	public CustomAddress() {
		
	}
	
	@Override
	public int doStartTag() throws JspException {
		JspWriter out = pageContext.getOut();
		
		try {
			out.println("<h1>DXC-Tech</h1>");
			out.println("DGC-Campus Phase-1,<br>\r\n "
					+ "HP Avenue");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return super.doStartTag();
	}

}