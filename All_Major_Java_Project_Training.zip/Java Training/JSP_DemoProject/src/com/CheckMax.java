package com;

public class CheckMax {

	public int max(int n1, int n2) {
		
		if(n1>n2) {
			return n1;
		}
		
		else {
		
		return n2;
		}
	}
	
	
}
