package com;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class CustomPrint extends TagSupport {
	
	public CustomPrint() {
		
	}
	String name;
	String times;
	
	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getTimes() {
		return times;
	}


	public void setTimes(String times) {
		this.times = times;
	}
  

	@Override
	public int doStartTag() throws JspException {
		JspWriter out = pageContext.getOut();
		int noOfTime = Integer.parseInt(times);
		
		try {
			for(int i=0;i<noOfTime;i++) {
				out.println("<h1>"+ name);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return super.doStartTag();
	}

}