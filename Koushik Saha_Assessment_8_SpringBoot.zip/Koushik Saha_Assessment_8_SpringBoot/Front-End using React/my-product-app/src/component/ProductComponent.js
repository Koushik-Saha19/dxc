import React, { Component } from 'react'
import ProductDataService from '../service/ProductDataService'
import {Formik,Form,Field, ErrorMessage} from 'formik'
class ProductComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            productId:this.props.match.params.prodId,
            productName:'',
            quantityOnHand:'',
            price:'',
            button:"Update",
            status1:true
        }
        this.onSubmit = this.onSubmit.bind(this)
        this.validateProductForm = this.validateProductForm.bind(this)
    }

    componentWillMount(){
        if(this.state.productId==-1){
            this.setState({
                button:"Add",
                productId:"",
                status1:false
            })
            return;
        }
        ProductDataService.getProduct(this.state.productId).then(response => {
            this.setState({
              productName: response.data.productName,
              quantityOnHand:response.data.quantityOnHand,
              price: response.data.price,
            });
            //console.log(status1)
          });
          
        }
  
    onSubmit(product){
        if(this.state.productId==""){     
            console.log("Hi")  
            ProductDataService.addProduct(product).then(response=>
                {this.props.history.push('/product');
                console.log(response.status)
            
            })

        }
        else
        {
         
        ProductDataService.updateProduct(product).then(()=>this.props.history.push('/product'))
        }
    }






    validateProductForm(values){
        let errors ={}
        if(!values.productId){
            errors.productId='Enter Product Id'
        }
        else  if(!values.productName){
            errors.productName='Enter Product Name'
        }
        else  if(!values.quantityOnHand){
            errors.quantityOnHand='Enter Quantity On Hand'
        }
        else  if(values.quantityOnHand<0){
            errors.price='Enter valid quantity on hand'
        }
        else  if(values.price<0){
            errors.price='Enter valid price'
        }
        else  if(values.productName.length<3){
            errors.productName='Enter at least 3 character'
        }
        return errors

    }
    render() {
        let{productId,productName,quantityOnHand,price}=this.state
        return (
            <div>
              <h3> Add/Update product</h3> 
             {/* <h3>Update product Id : {productId}</h3>
             <h3>Product Name: {productName}</h3>
             <h3>Quantity On hand: {quantityOnHand}</h3>
             <h3>Price: {price}</h3> */}
             <div className="container">
          <Formik initialValues={{productId,productName,quantityOnHand,price}}
           enableReinitialize={true} onSubmit={this.onSubmit} 
           validateOnBlur={false}
           validateOnChange={false}
           validate={this.validateProductForm}
           >
               
            
               <Form>

                   <ErrorMessage name="productId" component="div" className="alert alert-warning"></ErrorMessage>
                   <ErrorMessage name="productName" component="div" className="alert alert-warning"></ErrorMessage>
                   <ErrorMessage name="quantityOnHand" component="div" className="alert alert-warning"></ErrorMessage>
                   <ErrorMessage name="price" component="div" className="alert alert-warning"></ErrorMessage>
                   



                    <fieldset className="form-group">
                        <label>Product Id</label>
                        <Field className="form-control" type="text"name="productId" disabled={this.state.status1}></Field>
                    </fieldset>
                    <fieldset className="form-group">
                        <label>Product Name</label>
                        <Field className="form-control" type="text"name="productName"></Field>
                    </fieldset>
                    <fieldset className="form-group">
                        <label>Quantity On hand</label>
                        <Field className="form-control" type="text"name="quantityOnHand"></Field>
                    </fieldset>
                    <fieldset className="form-group">
                        <label>Price</label>
                        <Field className="form-control" type="text"name="price"></Field>
                    </fieldset>
                    <button className="btn btn-success"type="submit">{this.state.button}</button>
                    
               </Form>
          </Formik>
          </div>

</div>
        )
    }
}

export default ProductComponent