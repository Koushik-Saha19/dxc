import React, { PureComponent } from "react";
import ProductDataService from "../service/ProductDataService";

class ListProductComponent extends PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      product: [],
      message: ""
    };
    this.refreshProduct = this.refreshProduct.bind(this);
    this.deleteProductClick = this.deleteProductClick.bind(this);
    this.updateProductClick = this.updateProductClick.bind(this);
    this.searchProductClick = this.searchProductClick.bind(this)
  }

  componentWillMount() {
    this.refreshProduct();
  }
  refreshProduct() {
    ProductDataService.getAllProducts().then(response => {
      this.setState({
        product: response.data
      });
    });
  }
  deleteProductClick(productIdToDelete) {
    ProductDataService.deleteProduct(productIdToDelete).then(response => {
      this.setState({
        message: "Product Id " + productIdToDelete + " deleted successfully"
      });
      this.refreshProduct();
    });
  }
  updateProductClick(productId) {
    this.props.history.push(`/product/${productId}`);
  }
  searchProductClick() {
    this.props.history.push(`/product/search/searchProduct/`);
  }
  render() {
    return (
      <div>
        <h3>
          <center>All Products for you</center>
        </h3>
        <div className="container">
          {this.state.message && (
            <div className="alert alert-success">{this.state.message}</div>
          )}

          <table className="table table-striped table-hover">
            <thead>
              <tr>
                <th>ProductId</th>
                <th>ProductName</th>
                <th>Quantity On Hand</th>
                <th>Price</th>
                <th>Delete</th>
                <th>Update</th>
              </tr>
            </thead>

            <tbody>
              {this.state.product.map(product => (
                <tr key={product.productId}>
                  <td>{product.productId}</td>
                  <td>{product.productName}</td>
                  <td>{product.quantityOnHand}</td>
                  <td>{product.price}</td>
                  <td>
                    <button
                      className="btn btn-warning"
                      onClick={() => this.deleteProductClick(product.productId)}
                    >
                      Delete
                    </button>
                  </td>
                  <td>
                    <button
                      className="btn btn-danger"
                      onClick={() => this.updateProductClick(product.productId)}
                    >
                      Update
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <button
          className="btn btn btn-outline-primary"
          onClick={() => this.updateProductClick(-1)}
        >
          Add Product
        </button>

        <button
          className="btn btn btn-outline-primary"
          onClick={() => this.searchProductClick()}
        >
          Search Product By Name
        </button>
      </div>
    );
  }
}

export default ListProductComponent;
