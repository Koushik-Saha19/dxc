import React, { Component } from "react";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      message: '',
      sentence:''
    };
  }
  callAPI() {
    //fetch("http://localhost:5000/Joe").then(res => res.text()).then(res => this.setState({ message: res }));
    fetch("http://localhost:5000/Jason").then(res => res.text()).then(res => this.setState({ message: res }));
    
  }
  componentWillMount() {
    this.callAPI();
  }
  render() {
    return (
      <div>
        <h1>Message received from node is: {this.state.message}</h1>
        {/* <h1>Message received from node is: {this.state.}</h1> */}

      </div>
    );
  }
}

export default App;
