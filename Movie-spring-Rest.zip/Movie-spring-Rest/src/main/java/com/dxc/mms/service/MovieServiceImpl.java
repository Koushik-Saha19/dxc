package com.dxc.mms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dxc.mms.dao.MovieDAO;
import com.dxc.mms.model.Movie;

@Service
public class MovieServiceImpl implements MovieService {

	@Autowired
	MovieDAO movieDAO;
	@Override
	public List<Movie> getAllMovie() {
		
		return null;
	}

	@Override
	public boolean addMovie(Movie movie) {
		
		return movieDAO.addMovie(movie);
	}

	@Override
	public boolean deleteMovie(int movieId) {
		
		return movieDAO.deleteMovie(movieId);
	}

	@Override
	public boolean updateMovie(Movie movie) {
		
		return movieDAO.updateMovie(movie);
	}

	@Override
	public Movie getMovieById(int movieId) {
		
		return movieDAO.getMovieById(movieId);
	}

	@Override
	public boolean isMovieExist(int movieId) {
		
		return movieDAO.isMovieExist(movieId);
	}

	
}
