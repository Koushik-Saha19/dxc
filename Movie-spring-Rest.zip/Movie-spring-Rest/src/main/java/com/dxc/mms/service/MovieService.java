package com.dxc.mms.service;

import java.util.List;

import com.dxc.mms.model.Movie;

public interface MovieService {

	
	public List<Movie> getAllMovie();
	public boolean addMovie(Movie movie);
	public boolean deleteMovie(int movieId);
	public boolean updateMovie(Movie movie);
	public Movie getMovieById(int movieId);
	public boolean isMovieExist(int movieId);
	
}