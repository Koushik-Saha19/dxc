package com.dxc.assess.dao;

import com.dxc.assess.model.Users;

public interface UsersDAO {
	
	public boolean userValidate(Users user);
	
	public void getAllTrainingDetails();
	
	public void updatePercentage();
	
}