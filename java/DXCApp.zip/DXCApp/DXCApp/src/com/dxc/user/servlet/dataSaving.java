package com.dxc.user.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.dxc.user.dao.*;
import com.dxc.user.model.*;

public class dataSaving extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public dataSaving() {
        
       
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String fullName = request.getParameter("fullName");
		String gender  =  request.getParameter("gender");
		
		UserFormDAO u1 = new UserFormDAOImpl();
		
		
		
		UserForm userForm = new UserForm(username, password,fullName,gender);
		
		
		if(u1.isUserNameExist(username)) {
			response.sendRedirect("usernameExist.html");
		}
		else {
		
		//UserFormDAO userFormDAO = new UserFormDAOImpl();
		u1.addUser(userForm);
		response.getWriter().println("<h2>You are successfully registered, Please<a href='loginForm.html'>Login</a></h2>");
		
		}
		
		
		
		
		
		
	}

}
