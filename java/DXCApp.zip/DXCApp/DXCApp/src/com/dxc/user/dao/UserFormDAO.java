package com.dxc.user.dao;

import com.dxc.user.model.UserForm;

public interface UserFormDAO {
			public void addUser(UserForm userForm);
			public boolean validateUser(String username,String password);
			public boolean isUserNameExist(String username);
}
