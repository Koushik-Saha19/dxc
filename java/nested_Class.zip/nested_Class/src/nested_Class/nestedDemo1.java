package nested_Class;

import nested_Class.CheckPassword.PasswordDecrypt;

class CheckPassword{
	private int i = 100;
	class PasswordDecrypt{
		int j = 200;
		void encryptionDone() {
			System.out.println("Password verification Done");
		}
	}
	public void display() {
		PasswordDecrypt decrypt = new PasswordDecrypt();
		decrypt.encryptionDone();
	}
}


public class nestedDemo1 {
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		CheckPassword passwod = new CheckPassword();
		passwod.display();
		CheckPassword.PasswordDecrypt decrypt = passwod.new PasswordDecrypt();
		decrypt.encryptionDone();
	}

}
