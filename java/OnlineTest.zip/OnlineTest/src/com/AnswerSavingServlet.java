package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/AnswerSavingServlet")
public class AnswerSavingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public AnswerSavingServlet() {
        super();
       
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String strbatsman = request.getParameter("batsman");
		String strbowler = request.getParameter("bowler");
		HttpSession sesssion = request.getSession();
		sesssion.setAttribute("bestBatsman", strbatsman);
		sesssion.setAttribute("bestBowler", strbowler);
		
		if(strbowler!= null) {
			response.getWriter().println("<h1>Thank You, for taking the test</h1>");
		}
		else {
		response.sendRedirect("question2.html");
		}
		response.getWriter().println("<h1>Answer to the question 1 " + strbatsman + "</h1>");
		
		
		if(strbatsman == "ViratKholi") {
			response.getWriter().println("<h1>Answer to the question 1 is CORRECT</h1>");
		}
		else {
			response.getWriter().println("<h1>Answer to the question 1 is FALSE</h1>");
		}
		
	}

}
