package com.assessment.quiz.dao;

import java.util.List;

import com.assessment.quiz.model.Quiz;

public interface QuizDAO {

	public List<Quiz> displayQuestion();
	
	public int calculateResult();
	
}
