package com.repo;

import org.springframework.data.repository.CrudRepository;

import com.entity.Address;

public interface AddressRepo extends CrudRepository<Address, Long>
{
}
