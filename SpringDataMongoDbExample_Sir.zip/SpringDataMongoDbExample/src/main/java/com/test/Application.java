package com.test;

import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

import com.entity.Address;
import com.entity.Person;
import com.repo.AddressRepo;
import com.repo.PersonRepo;

public class Application {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				new ClassPathResource("spring-config.xml").getPath());
		PersonRepo personRepo = context.getBean(PersonRepo.class);
		AddressRepo addressRepo = context.getBean(AddressRepo.class);

		Person person = new Person();
		person.setPersonId(1l);
		person.setName("Balaji");
		personRepo.save(person);

		Person person2 = new Person();
		person2.setPersonId(2l);
		person2.setName("Vedula");

		Address address = new Address(12111, "BTM", "1st Stage", "Bangaore", 560029l);
		Address address2 = new Address(12112, "Marathalli", "1st Stage", "Bangaore", 560029l);

		List<Address> addresses = person2.getAddresses();
		addresses.add(address);
		addresses.add(address2);

		person.setAddresses(addresses);

		addressRepo.save(address);
		addressRepo.save(address2);

		personRepo.save(person2);

		Iterable<Person> personList = personRepo.findAll();
		System.out.println("Person List : ");
		for (Person p : personList) {
			System.out.println(p);
		}

		System.out.println("Person with Id 1 is " + personRepo.searchByName("Vedula"));

		context.close();

	}
}
