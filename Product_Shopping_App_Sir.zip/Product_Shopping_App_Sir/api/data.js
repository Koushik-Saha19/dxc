const products = [
  {
    id: 01,
    name: 'Product 1',
    available_quantity: 5,
    price: 450,
    description: 'Lorem ipsum dolor sit amet, iusto appellantur vix te, nam affert feugait menandri eu. Magna simul ad est. Nostrum neglegentur ius at, at pertinax repudiare vel. Vim an adolescens quaerendum.'
  },

  {
    id: 02,
    name: 'Product 2',
    available_quantity: 7,
    price: 50,
    description: 'Lorem ipsum dolor sit amet, iusto appellantur vix te, nam affert feugait menandri eu. Magna simul ad est. Nostrum neglegentur ius at, at pertinax repudiare vel. Vim an adolescens quaerendum.'
  },

  {
    id: 03,
    name: 'Product 3',
    available_quantity: 0,
    price: 500,
    description: 'Lorem ipsum dolor sit amet, iusto appellantur vix te, nam affert feugait menandri eu. Magna simul ad est. Nostrum neglegentur ius at, at pertinax repudiare vel. Vim an adolescens quaerendum.'
  },

  {
    id: 04,
    name: 'Product 4',
    available_quantity: 4,
    price: 1500,
    description: 'Lorem ipsum dolor sit amet, iusto appellantur vix te, nam affert feugait menandri eu. Magna simul ad est. Nostrum neglegentur ius at, at pertinax repudiare vel. Vim an adolescens quaerendum.'
  },
];



const users = [
    {
      'name': 'tufail',
      'password': 'ahmed'
    },
    {
      'name': 'mohan',
      'password': 'sharma'
    }
];

module.exports = { 'products': products, users: users }