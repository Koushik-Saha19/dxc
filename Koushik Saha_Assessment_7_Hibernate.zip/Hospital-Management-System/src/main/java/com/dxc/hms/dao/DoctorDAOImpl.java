package com.dxc.hms.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dxc.hms.model.Doctor;

import com.dxc.pms.util.HibernateUtil;

public class DoctorDAOImpl implements DoctorDAO {

	SessionFactory sf = HibernateUtil.getSessionFactory();
	
	
	public Doctor getDoctor(int doctorId) {
		Session session = sf.openSession();
		Doctor doctor = (Doctor)session.get(Doctor.class, doctorId);
		session.close();	
		return doctor;
	}

	public List<Doctor> getAllDoctor() {
		Session session = sf.openSession();
		Query query = session.createQuery("from Doctor");
		
		return query.list();
	}

	public boolean addDoctor(Doctor doctor) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(doctor);
		transaction.commit();
		session.close();
		System.out.println(doctor.getDoctorName() + "saved successfully");
		return true;
	}

	public boolean deleteDoctor(int doctorId) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		Doctor doctor = new Doctor();
		doctor.setDoctorId(doctorId);
		session.delete(doctor);
		transaction.commit();
	    session.close();
		return true;
	}

	public boolean updateDoctor(Doctor newDoctor) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.update(newDoctor);
		transaction.commit();
		session.close();
		return true;
	}

	public boolean isDoctorExists(int doctorId) {
		Session session = sf.openSession();
		Doctor doctor = (Doctor)session.get(Doctor.class,doctorId);
		if(doctor==null)
			return false;
		else
			return true;
	}

	public List<Doctor> getDoctorByName(String doctorName) {
		
		Session session = sf.openSession();
		String string = "FROM Doctor AS D WHERE D.doctorName = :doctorName";
		Query query = session.createQuery(string);
		query.setString("doctorName", doctorName);
		List<Doctor> list = query.list();
		return list;
	}

	
}
