package com.dxc.hms.dao;

import java.util.List;

import com.dxc.hms.model.Doctor;
import com.dxc.hms.model.Hospital;

import junit.framework.TestCase;

public class DoctorDAOImplTest2 extends TestCase {

	DoctorDAOImpl impl;
	
	
	protected void setUp() throws Exception {
		impl = new DoctorDAOImpl();
	}


	
	public void testGetDoctorsByName() {
		Hospital hospital = new Hospital("ABC", "Delhi");
		Doctor doctor = new Doctor(998, "Rohan", 12, hospital);
		Doctor doctor2 = new Doctor(999, "Rohan", 12, hospital);
		impl.addDoctor(doctor);
		impl.addDoctor(doctor2);
		List<Doctor> allDoctors = impl.getDoctorByName("Rohan");

		assertEquals(2, allDoctors.size());
		impl.deleteDoctor(doctor.getDoctorId());
		impl.deleteDoctor(doctor2.getDoctorId());
	}
}
