package com.dxc.hms.dao;



import java.util.List;

import com.dxc.hms.model.Doctor;
import com.dxc.hms.model.Hospital;

import junit.framework.TestCase;

public class DoctorDAOImplTest extends TestCase {

	
	DoctorDAOImpl impl;
	
	public DoctorDAOImplTest(String name) {
		super(name);
	}

	protected void setUp() throws Exception {
		impl = new DoctorDAOImpl();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	
	
	
	
	
	public void testGetDoctor() {
		Hospital hospital1 = new Hospital("Aiims1","mumbai");
		Doctor doctor1= new Doctor(126, "Raj1", 2890,hospital1 );
		impl.addDoctor(doctor1);
		Doctor doctor2= impl.getDoctor(126);
		assertEquals(doctor1.getDoctorId(),doctor2.getDoctorId());
		
		
	}

	public void testGetAllDoctor() {
		Hospital hospital1 = new Hospital("abc1","def");
		Doctor doctor = new Doctor(910,"Ram1",112,hospital1);
		List<Doctor> allDoctor1 = impl.getAllDoctor();
		impl.addDoctor(doctor);
		List<Doctor> allDoctor2 = impl.getAllDoctor();
		assertSame(allDoctor2.size(), allDoctor1.size()+1);
		
	}

	public void testAddDoctor() {
		Hospital hospital1 = new Hospital("xyz1","mumbai");
		Doctor doctor = new Doctor(225,"Rahul1",129,hospital1);
		List<Doctor> allDoctor1 = impl.getAllDoctor();
		impl.addDoctor(doctor);
		List<Doctor> allDoctor2 = impl.getAllDoctor();
		assertNotSame(allDoctor2.size(), allDoctor1.size());
	}

	public void testDeleteDoctor() {
		
		int doctorId = 908;
		List<Doctor> allProduct1 = impl.getAllDoctor();
		impl.deleteDoctor(doctorId);
		List<Doctor> allDoctor2 = impl.getAllDoctor();
		assertSame(allProduct1.size()-1,allDoctor2.size());
	}

	public void testUpdateDoctor() {
		Hospital hospital1 = new Hospital("pqr1","mumbai");
		Hospital hospital2 = new Hospital("rst1","mumbai");
		Doctor doctor1 = new Doctor(1065,"jadu",10,hospital1);
		impl.addDoctor(doctor1);
		Doctor doctor2 = new Doctor(1065,"mouse6",10,hospital2);
		impl.updateDoctor(doctor2);
		assertNotSame(doctor1.getDoctorName(),doctor2.getDoctorName());
	}

	
	
	
	public void testIsDoctorExists() {
		Hospital hospital1 = new Hospital("Aiims1","mumbai");
		Doctor doctor1= new Doctor(5, "madu", 12, hospital1);
		impl.addDoctor(doctor1);
		assertEquals(true, impl.isDoctorExists(doctor1.getDoctorId()));
	}
	
 

}
