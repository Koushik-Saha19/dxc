package com.joe;

/**
 * Hello world!
 *
 */
public class App 
{
    public String message(String msg){
     Date d = new Date();
     if(d.getHours()>10)
     return msg + "Good Morning"
     else 
     return msg + "Good Night
}

    public static void main( String[] args )
    {

        System.out.println( "Hello World!" );

        App p = new App();
        p.messag

    }
}
