var express = require("express");

var app = express();
app.set("view engine", "ejs");

var fs = require("fs");
var fileData = fs.readFileSync("./resources/about.txt", "utf8");

app.get("/", function(request, response) {
    response.send("<h1> Hi Welcome to our company</h1>");
});
app.get("/about", function(request, response) {
 
  response.render("about", { data: fileData });
});

console.log("Server started on port: 5000");

app.listen(5000);
