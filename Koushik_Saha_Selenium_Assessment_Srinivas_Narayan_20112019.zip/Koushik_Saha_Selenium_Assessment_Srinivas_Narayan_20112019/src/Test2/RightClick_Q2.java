package Test2;

import java.awt.AWTException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class RightClick_Q2 {

	public WebDriver driver;
	public String Browser="chrome";
	@Test
	public void testcase1() throws InterruptedException, AWTException{
		SoftAssert st = new SoftAssert();
		if(Browser.equalsIgnoreCase("chrome")){
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			driver=new ChromeDriver(); //OpenBrowser
		}else if(Browser.equalsIgnoreCase("mozilla")){
			System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
			 driver=new FirefoxDriver();
		}else if(Browser.equalsIgnoreCase("ie")){
			System.setProperty("webdriver.ie.driver", "IEDriverServer.exe");
			 driver=new InternetExplorerDriver();
		}
		driver.get("https://www.yahoo.com/"); //open url
		
		driver.manage().window().maximize(); //maximize browser
		
		//implicit delay time
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);//here we are giving implicit time = 10 seconds
		
		 WebElement news = driver.findElement(By.linkText("News"));
		
         Actions action = new Actions(driver);//"Actions" is a built-in class by using which we can do all mouse operations 
		
		action.contextClick(news).build().perform();//"contextClick" is used for right click in mouse 
}
}