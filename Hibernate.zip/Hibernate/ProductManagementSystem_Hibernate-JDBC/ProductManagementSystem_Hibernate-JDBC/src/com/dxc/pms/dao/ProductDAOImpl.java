package com.dxc.pms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.dxc.pms.dbcon.DBConnection;
import com.dxc.pms.model.Product;

public class ProductDAOImpl implements ProductDAO {
	
	Connection connection = DBConnection.getConnection();
	
	private static final String FETCH_PRODUCT_ALL = "select * from product";
	private static final String DELETE_PRODUCT= "delete from product where productId = ?";
	private static final String FETCH_PRODUCT_BY_ID = "select * from product where productId = ?";
	private static final String PRODUCT_UPDATE_QUERY = "update product set productName = ? , quantityOnHand= ? , price = ? where productId = ?";
	
	
	
	public ProductDAOImpl() {
	}
	@Override
	public List<Product> getAllProducts() {
		List<Product> allProducts = new ArrayList<Product>();
		try {
			Statement stat = connection.createStatement();
			ResultSet res = stat.executeQuery(FETCH_PRODUCT_ALL);
			while(res.next()) {
				Product product = new Product();
				product.setProductId(res.getInt(1));
				product.setProductName(res.getString(2));
				product.setQuantityOnHand(res.getInt(3));
				product.setPrice(res.getInt(4));
				allProducts.add(product);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return allProducts;
	}

	@Override
	public void addProduct(Product product) {
			//allProducts.add(product);
			try {
				PreparedStatement preparedStatement = 
						connection.prepareStatement("insert into product values (?,?,?,?)");
				preparedStatement.setInt(1, product.getProductId());
				preparedStatement.setString(2, product.getProductName());
				preparedStatement.setInt(3, product.getQuantityOnHand());
				preparedStatement.setInt(4, product.getPrice());
				
				preparedStatement.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	}



	
	@Override
	public Product getProduct(int productId) {
		Product product = new Product();
		
		try {
			PreparedStatement statement = connection.prepareStatement(FETCH_PRODUCT_BY_ID);
			statement.setInt(1, productId);
			
			ResultSet res = statement.executeQuery();
		
			product.setProductId(res.getInt(1));
			product.setProductName(res.getString(2));
			product.setQuantityOnHand(res.getInt(3));
			product.setPrice(res.getInt(4));
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return product;
	}

	@Override
	public void deleteProduct(int productId) {
		try {
			PreparedStatement statement = connection.prepareStatement(DELETE_PRODUCT);
			statement.setInt(1, productId);
			
			statement.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	

	@Override
	public void updateProduct(Product product) {
		
		
		//allProducts.add(product);
		try {
			PreparedStatement preparedStatement = 
					connection.prepareStatement(PRODUCT_UPDATE_QUERY);
			
			preparedStatement.setInt(4, product.getProductId());
			preparedStatement.setString(1, product.getProductName());
			preparedStatement.setInt(2, product.getQuantityOnHand());
			preparedStatement.setInt(3, product.getPrice());
			
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public boolean isProductExists(int productId) {
		boolean productExists = false;
		PreparedStatement preparedStatement;
		try {
			preparedStatement = connection.prepareStatement(FETCH_PRODUCT_BY_ID);
			preparedStatement.setInt(1, productId);
			
			ResultSet res = preparedStatement.executeQuery();
			if(res.next())
				productExists = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
		return productExists;
	}

}
