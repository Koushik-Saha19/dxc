var fs= require('fs')

//pipe is used to transfer the whole data..it is vary shortcut and fast way to transfer the data...otherwise we can also transfer data in chunks also
var myReadStream = fs.createReadStream('./Hello.txt','utf-8');

var myWriterStream = fs.createWriteStream('./data.txt','utf-8');


myReadStream.pipe(myWriterStream)
 