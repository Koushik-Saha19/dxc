var fs= require('fs')

var myReadStream = fs.createReadStream('./Hello.txt','utf-8');

var myWriterStream = fs.createWriteStream('./data.txt','utf-8');


myReadStream.on('data',function(chunk){
    console.log('new chunk received :');
    myWriterStream.write(chunk);
})
