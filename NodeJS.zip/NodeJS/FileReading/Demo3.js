var fs = require("fs")
//Here Async calling is going on...that's why "Done" will printed first then it will print data of "takeHomeSalary.txt"
fs.readFile("takeHomeSalary.txt","utf8",function(err,data){
    if(err){
        console.log(err.message)
    }
    else console.log(data)
})
console.log("Done");
