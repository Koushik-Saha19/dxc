var fs = require("fs")
// here we are deleting the file "takeHomeSalary2.txt"
fs.unlink("takeHomeSalary2.txt",function(err){
    if(err){
        console.log(err.message)
    }
   
})
console.log("Done");


// var fs = require("fs")
// fs.mkdir('stuff',function(){
//    fs.readFile("readMe.txt","utf-8",function(err,data){
//        fs.writeFileSync('./stuff/writeMe.txt',data)
//    });
// });

