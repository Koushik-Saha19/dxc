module.exports.counter = function(arr){
    return "There are " + arr.length + " elements in the array"
}

 module.exports.adder= function(a,b){
    return `The sum of the 2 numbers : ${a+b}`
}

 module.exports.pi = 3.142

 //Another way of exporting
// module.exports.c = counter
// module.exports.a = adder
// module.exports.p = pi

//Another way of exporting
// module.exports={

//     c:counter,
//     a:adder,
//     p:pi
// }
