var server4 = require('./server3')
var router = require('./routerPrime')

server4.start(9999,router.routePrime)