
var mongoose =require("mongoose")

module.exports = function (app) 
{
    app.get('/todo', function (request, response) 
    { 
        let data = {
            todo : [ "Eating","Sleeping","Watching movies"]
        }

        //by this we are making connection
       
        mongoose.connect("mongodb+srv://Koushik-Saha19:mongodb1234@cluster0-ou2xy.mongodb.net/test?retryWrites=true&w=majority")
        console.log("Connected to cloud mongodb")

           //Schema
           var todoSchema = new mongoose.Schema({
            item: String
        })

        //Model
        var Todo = mongoose.model('Todo', todoSchema)

        //adding data to db
        var oneItem = Todo({
            item: "bottle"
        }).save(function(err){
            if(err) 
                console.log(err)
               console.log("Item Saved")
               throw err;
            
        })
        response.render("todo",{arr: data})
    });
    app.post('/todo', function (request, response) 
    { 
        response.send("TODO POST")
    });
    app.delete('/todo', function (request, response) 
    {
        response.send("TODO DELETE")
    });
};
