function start(){
    console.log("Request handler 'start' was called")
    
}

function upload(){
    console.log("Request handler 'upload' was called")
}

function download(){
    console.log("Request handler 'download' was called")
}

function imageUplaod(){
    console.log("Request handler 'imageUplaod' was called")
}

exports.start= start
exports.upload= upload
exports.download= download
exports.imageUplaod= imageUplaod