var express = require("express");

var app = express();
app.set('view engine', 'ejs');

app.use('./assets',express.static("assets"))
app.get("/productViewEJS",function(request,response){
    response.render("product")
})

app.get("/product",function(request,response){
    response.send("Hello and welcome to express get")//in this way we can send any file also
})
app.get("/productFile",function(request,response){
    response.sendFile(__dirname +"/index.html")
})
// app.get("/product/:pId/orders/:oId",function(request,response){
//     response.send("Product Details for product Id: " + request.params.pId + " Order Details for : " + request.params.oId)
// })

app.get("/product/:pId/orders/:oId",function(request,response){
    response.render("product",
                             {datapId: request.params.pId,
                              dataoId: request.params.oId}
    )
})
app.post("/productSave",function(request,response){
    response.send("Hello and welcome to express post")
})
app.put("/productUpdate",function(request,response){
    response.send("Hello and welcome to express put")
})
app.delete("/productDelete",function(request,response){
    response.send("Hello and welcome to express delete")
})

console.log("Server started on port: 5001")

app.listen(5001);