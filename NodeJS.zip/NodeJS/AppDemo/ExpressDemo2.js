var express = require("express");

var app = express();
app.set('view engine', 'ejs');

// app.get("/productViewEJS",function(request,response){
//     response.render("profile")
// })

app.get("/profile/:name",function(request,response){
    
    var data ={ age: 30, job: 'Cricketer',hobbies: ['Travelling','Watching movies','Playing Football']}
    
    response.render("profile",
                             {person: request.params.name,
                              data: data
                            }
    )
})

console.log("Server started on port: 5001")

app.listen(5001);