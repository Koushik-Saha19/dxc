
var stuff = require('./Demo1')

console.log(stuff.counter(['Joe','Jason','Ben']))
console.log(stuff.adder(2,3))
console.log(stuff.pi)
