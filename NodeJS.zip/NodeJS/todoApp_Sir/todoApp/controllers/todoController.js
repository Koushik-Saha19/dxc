var data = [];
const bodyParser = require('body-parser')
var MongoClient = require('mongodb').MongoClient;
var url = 'mongodb://localhost:27017';
var db;

MongoClient.connect(url, (err, client) => {
    db = client.db('itemdb');
    db.collection('todo').find({}).toArray(function (err, docs) {
        docs.forEach(function (doc) {
            console.log(doc);
            //data = doc.itemName;
            data = docs;
        });
        console.log("Connected Successfully !!")
    });
});

module.exports = function (app) {
    app.use(
        bodyParser.urlencoded({
            extended: true
        })
    )
    app.use(bodyParser.json())

    app.get('/todo', function (request, response) {
        console.log(data)
        response.render("todo", { todos: data });
    });

    app.post('/todo', function (request, response) {
        //retrieving the item name 
        var itemName = request.body.itemName;
        var myobj = { itemName: itemName };
        //adding the item in mongo db database
        var oneItem = db.collection('todo').insertOne(myobj, function (err) {
            if (err)
                console.error(err);
            console.log("item saved");
        })
        response.render("todo", { todos: data });

    });
    app.delete('/todo', function (request, response) {
        response.send("TODO DELETE")
    });
};
