var server3 = require('./server3')

server3.start()