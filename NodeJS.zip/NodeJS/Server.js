var http = require("http")
var server = http.createServer(function(request,response){
response.writeHead(404,{"Content-type":"text-html"})
response.write("Your name is Joe Root")
response.end()
});
server.listen(8888)
console.log("server started on port number: 8888")