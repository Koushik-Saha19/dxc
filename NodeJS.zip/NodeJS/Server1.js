var http = require("http")

function onRequest(req,res){
    res.writeHead(201,{"Content-type":"text-plain"})
    res.write("Your name is Jason Roy")
    res.end();
}
var server = http.createServer(onRequest)
server.listen(8888)
console.log("server started on port number: 8888")
