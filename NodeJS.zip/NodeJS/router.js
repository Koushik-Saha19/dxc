function route(pathname){
    console.log("2.your request will be routed to:" + pathname)
}

exports.route = route