var http = require("http");
var url = require('url');
var router = require("./router");

function start(){
    function onRequest(req,res){
        res.writeHead(201,{"Content-type": "text-plain"})
        var pathname = url.parse(req.url).pathname
        console.log("1.The requested current url is:" + pathname)
        router.route(pathname)
        console.log("3.The requested current url is:" + pathname)
        res.write("Your name is Brettly")
        res.end()
    }
    var server = http.createServer(onRequest)
    server.listen(8888)
    console.log("server started on port number: 8888")
}

exports.start = start