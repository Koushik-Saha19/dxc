var data = [{ item: 'mouse' }, { item: 'keyboard' }, { item: 'motherboard' }];
var mongoose = require("mongoose")
const bodyParser = require('body-parser')

 //connection cloud
 mongoose.connect(" mongodb+srv://Koushik-Saha19:mongodb12345@cluster0-ou2xy.mongodb.net/test?retryWrites=true&w=majority")
 //schema
 var todoSchema = new mongoose.Schema({
     item: String
 })

 //Model
 var Todo = mongoose.model('Todo', todoSchema)

module.exports = function (app) {

    app.use(
        bodyParser.urlencoded({
            extended: true
        })
    )

    app.use(bodyParser.json())

    app.get('/todo', function (request, response) {

        Todo.find(function(err, d) {
            data = d
        })
        console.log(data)
        response.render("todo", { todos: data });
    });

    app.post('/todo', function (request, response) {

        var itemName = request.body.itemName
         
        //adding the item in mongo db database
        var oneItem = Todo({ item: itemName }).save(function (err) {
            if (err)
                console.error(err);
            console.log("item saved");
        })

        response.render("todo", { todos: data });
    });
    app.delete('/todo', function (request, response) {
        response.send("TODO DELETE")
    });
};
