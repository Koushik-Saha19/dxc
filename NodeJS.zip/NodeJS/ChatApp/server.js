var http = require("http");
var url = require("url")

function start(portNumber, route, handle) {
    function onRequest(request, response) {
      
        var pathname = url.parse(request.url).pathname
        if (request.url === '/favicon.ico') {
            response.writeHead(200, { 'Content-Type': 'image/x-icon' });
            return;
        }
        console.log("Server  has started on port number : " + portNumber)
        // route(pathname,handle)
        // response.end();
        console.log("I have recvd : "+pathname)
  




    }
    var server = http.createServer(onRequest)
    server.listen(portNumber);
    console.log("Server started on :"+portNumber)
}
exports.start = start