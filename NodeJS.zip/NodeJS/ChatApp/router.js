function route(pathname, handle,response) {
    if (typeof handle[pathname] == 'function') {
        console.log("HELLO I AM ROUTING :"+pathname)
        handle[pathname](response);
    }
    else {
        console.log("Sorry no handlers found for :" + pathname)
    }
}

exports.route = route
